package com.company;

public class Main {
    final public static double EDGE_CUM_PROB = 0.9;
    final public static double SENSOR_COR_PROB = 0.85;

    public static void main(String[] args) {
        //System.out.println("hello");
        Grid grid = new Grid();
        grid.takeActionInput();
        // write your code here
    }
}